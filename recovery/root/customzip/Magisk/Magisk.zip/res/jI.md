# alpha更新日志

重大行为变化：magiskd内部挂载点于不再使用后卸载。

新功能：强化的安全模式。如果连续两次不能正常开机，第三次Magisk会自动进入安全模式。
安全模式下关闭全部功能，禁用全部模块，仅Magisk应用可以使用su。
电脑调试请使用`adb shell 'PATH=$PATH:/debug_ramdisk su'`。

## Magisk (070719db-alpha)
- [App] 还原boot镜像后删除备份文件
- [App] 不主动请求权限
- [General] 保留ROOTOVL临时文件
- [App] 通过appcenter检查和下载更新
- [App] 添加遥测 https://t.me/s/magiskalpha/473
- [General] 移除addon.d支持
- [MagiskSU] 支持移除权能
- [General] 支持用户限制Root权能
- [App] 为DoH禁用SNI
- [MagiskBoot] 删除dtb功能
- [App] 刷入模块时忽略META-INF

# 上游更新日志

## 2024.10.10 Magisk v28.0

- [General] Support 16k page size
- [General] Add basic support for RISC-V (not built in releases)
- [General] Use a minimal libc to build static executables (`magiskinit` and `magiskboot`) for smaller sizes
- [Core] Remove unnecessary mirror for magic mount
- [Core] Update boot image detection logic to support more devices
- [MagiskInit] Rewrite 2SI logic for injecting `magiskinit` as `init`
- [MagiskInit] Update preinit partition detection
- [Zygisk] Update internal JNI hooking implementation
- [MagiskPolicy] Preserve sepolicy config flag after patching
- [MagiskPolicy] Optimize patching rules to reduce the amount of new rules being injected
- [DenyList] Support enforcing denylist when Zygisk is disabled
- [Resetprop] Improve implementation to workaround several property modification detections
- [Resetprop] Update to properly work with property overlays
- [App] Major internal code refactoring
- [App] Support patching Samsung firmware with images larger than 8GiB
- [App] Use user-initiated job instead of foreground services on Android 14
- [App] Support Android 13+ built-in per-app language preferences
- [App] Add `action.sh` support to allow modules to define an action triggered from UI
- [MagiskBoot] Support spliting kernel images without decompression
- [MagiskBoot] Properly support vendor boot images
- [MagiskBoot] Disable Samsung PROCA from kernel image
